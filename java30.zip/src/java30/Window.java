package java30;

public interface Window {
	public void open();
	public void close();
}
