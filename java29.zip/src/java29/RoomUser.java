package java29;

public class RoomUser {

	public static void main(String[] args) {
		MyRoom room = new MyRoom();
		AppleSpeaker s = new AppleSpeaker();
		room.music(s);
	}

}
