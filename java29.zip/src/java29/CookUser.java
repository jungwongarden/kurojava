package java29;

public class CookUser {

	public static void main(String[] args) {
		Book book = new CookBook();
		book.read();
	}

}
