package java30;

public class YourCar {
	public static void main(String[] args) {
		Speaker k = new BananaSpeaker();
		k.soundUp();
		k.soundDown();
	}
}
