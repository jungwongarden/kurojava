package Ŭ�����⺻;

import java.util.Date;

public class DateUser {

	public static void main(String[] args) {
		Date date = new Date();
		int hour = date.getHours();
	}

}
