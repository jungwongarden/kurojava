package java29;

public class ComputeBook implements Book{
	@Override
	public void read() {
		System.out.println("자바 책을 읽다.");
	}
}
