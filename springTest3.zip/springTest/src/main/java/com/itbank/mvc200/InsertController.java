package com.itbank.mvc200;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class InsertController {
	
	@RequestMapping("insert.do")
	public void insert(MemberDTO memberDTO, 
			@RequestParam("id") String id) throws Exception{
		System.out.println("내가 호출되었군요...., ");
		MemberDAO dao = new MemberDAO();
		System.out.println(id);
		dao.insert(memberDTO);
		
	}
	
	@RequestMapping("insert2.do")
	public void insert2(){
		System.out.println("내가 호출되었군요....");
	}
}
