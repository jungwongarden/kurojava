package java29;

public interface B {
	void b();
}
