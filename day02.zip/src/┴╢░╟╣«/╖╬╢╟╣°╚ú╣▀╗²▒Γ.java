package ���ǹ�;

import java.util.Random;

public class �ζǹ�ȣ�߻��� {

	public static void main(String[] args) {
		Random r = new Random();
		System.out.println(r.nextInt(3));
		System.out.println(r.nextInt(3));
		System.out.println(r.nextInt(3));
	}

}
