package java29;

public interface A {
	void a();
}
