package java29;

public interface Book {
	public abstract void read();
}
