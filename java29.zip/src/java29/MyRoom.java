package java29;

public class MyRoom {
	public void music(AppleSpeaker s) {
		s.soundUp();
		s.soundDown();
	}
}
