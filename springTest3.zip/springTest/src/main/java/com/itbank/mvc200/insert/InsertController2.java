package com.itbank.mvc200.insert;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.itbank.mvc200.MemberDAO;
import com.itbank.mvc200.MemberDTO;

@Controller
public class InsertController2 {
	
	@RequestMapping("insert3.do")
	public void insert(MemberDTO memberDTO, 
			@RequestParam("id") String id) throws Exception{
		System.out.println("내가 호출되었군요...., ");
		MemberDAO dao = new MemberDAO();
		System.out.println(id);
		dao.insert(memberDTO);
	}
	@RequestMapping("insert/insert2.do")
	public String insert2(){
		System.out.println("내가 호출되었군요....");
		return "insert2";
	}
	}
	
	
