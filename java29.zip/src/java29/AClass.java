package java29;

public class AClass implements A {

	@Override
	public void a() {
		System.out.println("A인터페이스 구현한 클래스..");
	}

}
