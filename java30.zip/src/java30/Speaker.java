package java30;

public interface Speaker {
//인터페이스 자동 추출 alt+shift+T+E	
	void soundUp();
	void soundDown();
}