package java29;

public class CookBook implements Book {

	@Override
	public void read() {
		System.out.println("레시피를 읽다.");
	}

}
