package java29;

public class CarUser2 {

	public static void main(String[] args) {
		Car2 blue = new BlueCar2();
		blue.start();
		blue.speedUp();
		blue.stop();
		//blue.sell();
		//blue.tour();
	}

}
