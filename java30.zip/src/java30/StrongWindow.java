package java30;

public class StrongWindow implements Window {

	@Override
	public void open() {
		System.out.println("강화유리로 열다.");
	}

	@Override
	public void close() {
		System.out.println("강화유리로 닫다.");
	}

}
