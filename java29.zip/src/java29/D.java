package java29;

public interface D extends C{
	void d();
}
