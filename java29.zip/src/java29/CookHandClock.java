package java29;

public class CookHandClock extends HandClock {

	@Override
	public void timeStop() {
		System.out.println("요리한 시각을 손목시계로 재다.");
	}

}
