package java30;

import java.util.HashMap;

public class MapTest {

	public static void main(String[] args) {
		HashMap member = new HashMap();
		member.put(100, "박아무개");
		member.put(200, "송아무개");
		member.put(300, "정아무개");
		System.out.println(member);
		System.out.println(member.get(100));
		
		
		
		
		
		
		
		
	}

}
