package java29;

public class EClass implements E {

	@Override
	public void a() {

	}

	@Override
	public void b() {

	}

	@Override
	public void c() {

	}

	@Override
	public void e() {

	}

}
