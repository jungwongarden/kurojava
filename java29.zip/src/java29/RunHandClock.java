package java29;

public class RunHandClock extends HandClock {

	@Override
	public void timeStop() {
		System.out.println("운동한 시각을 손목시계로 재다.");
	}

}
