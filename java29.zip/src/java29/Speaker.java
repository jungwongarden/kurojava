package java29;

public interface Speaker {
	void soundUp();
	void soundDown();
}
