package java29;

public class HandClockUser {

	public static void main(String[] args) {
		RunHandClock run = new RunHandClock();
		CookHandClock cook = new CookHandClock();
		run.timeStop();
		cook.timeStop();
		
		HandClock hand = new RunHandClock();
		
		
		
		
		
		
		
	}

}
