package java29;

public interface E extends A, B, C {
	void e();
}
