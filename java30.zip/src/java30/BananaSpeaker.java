package java30;

public class BananaSpeaker implements Speaker {
	public void add() {
		System.out.println("바나나 스피커 추가...");
	}
	public void soundUp() {
		System.out.println("바나나 스피커 소리 UP");
	}
	public void soundDown() {
		System.out.println("바나나 스피커 소리 DOWN");
	}
}
