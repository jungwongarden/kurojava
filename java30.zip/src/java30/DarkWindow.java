package java30;

public class DarkWindow implements Window{

	@Override
	public void open() {
		System.out.println("썬팅한 윈도우로 열다.");
	}

	@Override
	public void close() {
		System.out.println("썬팅한 윈도우로 닫다.");
		
	}

}
