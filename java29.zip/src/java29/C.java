package java29;

public interface C {
	void c();
}
