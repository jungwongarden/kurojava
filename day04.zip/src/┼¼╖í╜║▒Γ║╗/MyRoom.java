package Ŭ�����⺻;

public class MyRoom {

	public static void main(String[] args) {
		Phone p1 = new Phone();
		p1.shape = "�׸�";
		p1.size = 9;
		
		p1.call();
		p1.katalk();
		
		Phone p2 = new Phone();
		p2.shape = "���簢��";
		p2.size = 11;
		p2.katalk();
		
		
		
		
		
		
	}

}
