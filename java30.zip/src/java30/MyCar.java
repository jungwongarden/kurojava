package java30;

public class MyCar {
	public static void main(String[] args) {
		Speaker kiwi = new BananaSpeaker();
		kiwi.soundUp();
		kiwi.soundDown();
	}
}
