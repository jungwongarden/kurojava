package bean;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/hello") // 어노테이션(Annotation: 표시, 표기)
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public HelloServlet() {
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("GET방식 요청 들어옴....");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("POST방식 요청 들어옴....");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		//처리하는 부분에 db접속을 해서, id, pw가 맞는치 확인!!!
		
		response.getWriter().write("your id: " + id + "<br>");
		response.getWriter().write("your pw: " + pw + "<br>");
		
//		System.out.println("id: " + id);
//		System.out.println("pw: " + pw);
		
	}
}
