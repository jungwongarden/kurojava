package java29;

public class Car2 {
	public void start() {
		System.out.println("자동차가 출발하다.");
	}
	public void stop() {
		System.out.println("자동차가 정지하다.");
	}
	public void speedUp() {
		System.out.println("자동차가 속도를 내다.");
	}
}
