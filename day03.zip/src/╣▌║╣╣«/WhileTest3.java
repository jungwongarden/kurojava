package �ݺ���;

public class WhileTest3 {
	public static void main(String[] args) {
		int i = 0;
		while (i<10) {
			System.out.print("��");
			i++; 
		}
	}

}
