package shop;

public class BbsDTO {
	private String id;
	private String title;
	private String content;
	private String user;
	//알트+쉬프트+s+r
	//(get/set메소드 자동 생성)
	
	@Override
	public String toString() {
		return id + " " + title + " " + content + " " + user;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
}
