package java30;

public class AppleSpeaker {
	public void volumeUp() {
		System.out.println("사과 스피커의 소리를 UP");
	}
	public void volumeDown() {
		System.out.println("사과 스피커의 소리를 DWON");
	}
}
