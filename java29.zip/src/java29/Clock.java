package java29;

public interface Clock {
	void watch();
}
